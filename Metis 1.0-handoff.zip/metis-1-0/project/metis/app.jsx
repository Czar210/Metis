// Metis redesign canvas — main app.

function App() {
  return (
    <DesignCanvas>

      <DCSection id="main" title="Metis · Páginas principais"
        subtitle="Home, descoberta, análise de jogador e partida.">
        <DCArtboard id="home" label="01 · Home" width={1200} height={1400}>
          <ScreenHome/>
        </DCArtboard>
        <DCArtboard id="tierlist" label="02 · Tier List" width={1200} height={1400}>
          <ScreenTierList/>
        </DCArtboard>
        <DCArtboard id="player" label="03 · Player dashboard" width={1200} height={1600}>
          <ScreenPlayer/>
        </DCArtboard>
        <DCArtboard id="match" label="04 · Match detail · Overview" width={1260} height={2400}>
          <ScreenMatch/>
        </DCArtboard>
      </DCSection>

      <DCSection id="deep" title="Páginas de descoberta profunda"
        subtitle="Campeões e itens com estatísticas, builds, matchups.">
        <DCArtboard id="champion" label="05 · Champion page (4 tabs)" width={1200} height={1500}>
          <ScreenChampion/>
        </DCArtboard>
        <DCArtboard id="items" label="06 · Itens" width={1200} height={1600}>
          <ScreenItems/>
        </DCArtboard>
      </DCSection>

      <DCSection id="ai" title="IA Metis & Engajamento"
        subtitle="Chat, planos de assinatura, novidades.">
        <DCArtboard id="chat" label="07 · Chat Metis" width={1200} height={1100}>
          <ScreenChat/>
        </DCArtboard>
        <DCArtboard id="plans" label="08 · Planos (4 tiers)" width={1200} height={1200}>
          <ScreenPlans/>
        </DCArtboard>
        <DCArtboard id="changelog" label="09 · Changelog" width={1200} height={1300}>
          <ScreenChangelog/>
        </DCArtboard>
      </DCSection>

      <DCSection id="brand" title="Marca & Equipe">
        <DCArtboard id="team" label="10 · Equipe" width={1200} height={1000}>
          <ScreenTeam/>
        </DCArtboard>
      </DCSection>

      <DCPostIt top={20} left={20} rotate={-3} width={260}>
        <b>Metis redesign — 10 telas</b><br/>
        Clica num card para abrir em tela cheia. ← → troca entre telas. Esc sai.
        Dentro do Match Detail, tem 3 abas (Overview / Análise de Equipe / Builds).
      </DCPostIt>

    </DesignCanvas>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App/>);
